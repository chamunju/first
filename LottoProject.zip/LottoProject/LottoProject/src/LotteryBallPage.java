import javax.swing.JPanel;

public class LotteryBallPage extends JPanel{
	
	
	
}
