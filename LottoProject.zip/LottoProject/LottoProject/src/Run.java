import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Run extends JFrame {
   
    public static void main(String[] args) {
    	StartPage s = new StartPage();
    }
}

